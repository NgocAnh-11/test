Hướng dẫn sử dụng công cụ MISA.CA.CertChecker.exe
1. Tác dụng: Công cụ MISA.CA.CertChecker.exe xây dụng nhằm hỗ trợ xác định các lỗi phát sinh trong quấ trình sử dụng MISA Kyso
2. Các chức năng chính: Chương trình có 8 chức năng chính như sau
 --------------------------
1) Select Cert: Chọn một chứng thư
2) Check USB Token Connection: Kiểm tra kết nối với USB Token
3) Get PrivateKey: Thực hiện lấy khóa của chứng thư thông qua PrivateKey
4) Get RSAPrivateKEY: Thực hiện lấy khóa chứng thư  thông qua GetRSAPrivateKey
5) Check CertStatus: Kiểm tra trạng thái của chứng thư
6) CheckPort 11984, 11985, 12680, 12681, 12683, 11994, 11995, 12690,...: Kiểm tra một cổng bất kỳ của máy tính đang được mở bỏi dịch vụ nào
0) Exist: Thoát khỏi chương trình
100) Clean Screen: Làm sạch màn hình của tool MISA.CA.CertChecker.exe
--------------------------
3. Cách dùng
3.1 Chạy chương trình MISA.CA.CertChecker.exe, tại cửa sổ chương trình, thực hiện gõ số tương ứng với chức năng cần thực hiện
VD: Để kiểm tra xem danh sách chứng thư có chứng thư của khách hàng không ta dùng chức năng "1) Select Cert" thông qua gõ số 1 và nhấn enter
Chương trình sẽ hiển thị cửa sổ chọn chứng thư. Thực hiện chọn 1 chứng thư chương trình sẽ hiển thị thông tin chứng thư dạng
Selected cert: E=nguyenkimngockma@gmail.com, OID.0.9.2342.19200300.100.1.1=CCCD:042096013639, CN=NGUY?N KIM NG?C, L="Thôn Trung Nam H?ng, Xa Yên H?, Huy?n D?c Th?, Hà Tinh", S=Hà Tinh, C=VN
Select Cert:Success
3.2 Tương tự cho việc dùng các chứng năng khác (gõ số tương ứng với tính năng cần kiểm tra và gõ enter để thực hiện)
Lưu ý:  - Để thực hiện được các chức năng số 2,3,4,5 thì trước tiên phải thực hiện chức năng số 1 (Select Cert)
- Để sử dụng chức năng số 6: Kiểm tra 1 cổng được sử dụng bởi dịch vụ nào ta làm như sau: Tại cửa sổ gõ 6: Số cổng
VD: 6:11984 (tức là kiểm tra cổng số 11984) 
CheckPort 11984: Using by MISA.KYSO --> Cổng 11984 đang được MISA.KYSO sử dụng
- Tốt nhất chương trình được chạy với vai trò là Administrator để 
